webdict
=======

###2014-05-11更新###

webdict更新，从1GB果壳语料、750MB豆瓣语料、2GB腾讯新闻语料、2.5GB腾讯财经语料、500MB腾讯科技语料中进行新词发现，增加词语19739个。

webdict_with_freq.txt目前包含220934个词条

tagger.txt目前包含标注41685个

P.S. 写爬虫爬网页什么的都是泪啊QAQ

###2014-02-22更新###

webdict的第一个词库发布

webdict.txt是不包含词频的词库, 总共201195个词条。

webdict_with_freq.txt是包含了词频的词库, 总共154967个词条, 统计词频所用语料库总共1583096137个词。

两个词库使用到了[CC-CEDICT][1]的词表(CC BY-SA 3.0协议)

###2014-01-05更新###

截止今天webdict.info已经收集到了28923条词语标注，标注结果已经合并至tagged.txt。

目前正准备由Twitter语料切换到新闻和Twitter的混合语料中进行新词发现。

###2013-09-16更新###

webdict.info已经收集到了18849条词语标注，其中6346个是词语，已经合并至wendict.txt。

新增词语标注文件tagged.txt。

[1]: http://cc-cedict.org/wiki/

